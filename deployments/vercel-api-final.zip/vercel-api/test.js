import { createServer } from 'http';
import { URL } from 'url';
import chatHandler from './api/chat.js';

const server = createServer((req, res) => {
  if (req.url.startsWith('/api/chat')) {
    chatHandler(req, res);
  } else {
    res.writeHead(404);
    res.end('Not found');
  }
});

server.listen(3001, () => {
  console.log('Test server running on http://localhost:3001');
});