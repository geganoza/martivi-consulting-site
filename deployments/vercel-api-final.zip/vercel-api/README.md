# MC-Chat-230925

Martivi Consulting Chat API - Vercel Serverless Functions

## Features
- OpenAI GPT-4o-mini integration
- Georgian and English language support
- Lead capture functionality
- CORS enabled for cross-origin requests

## API Endpoint
- `GET /api/chat` - Health check
- `POST /api/chat` - Chat with AI assistant

## Environment Variables
- `OPENAI_API_KEY` - Your OpenAI API key
- `CORS_ORIGIN` - Allowed origins (comma-separated)
- `LEAD_WEBHOOK_URL` - Optional webhook for lead capture